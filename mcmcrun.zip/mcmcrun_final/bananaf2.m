function xz=bananaf2(x,pars)

xz=[x(:,1) x(:,2)+pars.b.*x(:,1).^2-100*pars.b x(:,3:end)];