function y=podfun(x,theta)

y = theta(1)*(1-exp(-theta(2)*x));