function y=nordf(x,mu,sigma2)
% NORDF Evaluate the standard normal (Gaussian) distribution.

% Marko Laine atkk 1991
% Uses the error function ERF

% Marko Laine <Marko.Laine@Helsinki.FI>
% $Revision: 1.3 $  $Date: 2003/10/31 19:36:58 $

if nargin < 2, mu     = 0; end
if nargin < 3, sigma2 = 1; end

%y = 0.5*erf(-Inf,sqrt(2)*0.5*x);
y = 0.5+0.5*erf((x-mu)/sqrt(sigma2)/sqrt(2));
