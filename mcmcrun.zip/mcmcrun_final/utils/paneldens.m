function paneldens(x,y)
% 2d-density to pairs plot. See PAIRS

% Marko Laine <Marko.Laine@Helsinki.FI>
% $Revision: 1.2 $  $Date: 2002/09/12 11:15:07 $

[z,xo,yo]=density2d([x,y]);
hold on
contour(xo,yo,z)
hold off
