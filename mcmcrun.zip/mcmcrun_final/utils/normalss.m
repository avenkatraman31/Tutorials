function y=normalss(x,Lam)
% Sum of squares for Gaussian test case for mcmcrun
% this is used by testmcmc
x0 = [0.5 0.5];
%y   = (abs(x)-x0)*Lam*((abs(x)-x0))';
%y   = (x.^2-x0)*Lam*((x.^2-x0))';
y   = (x-x0)*Lam*(x-x0)';
