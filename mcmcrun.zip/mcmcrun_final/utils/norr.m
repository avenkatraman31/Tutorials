function r=norr(m,n,mu,sigma2)
% NORR(m,n,mu,sigma2)  Normal (Gaussian) random numbers

% Marko Laine <Marko.Laine@Helsinki.FI>
% $Revision: 1.3 $  $Date: 2003/10/31 19:36:58 $

if nargin < 3, mu=0; end
if nargin < 4, sigma2=1; end
r = randn(m,n).*sqrt(sigma2) + mu;
