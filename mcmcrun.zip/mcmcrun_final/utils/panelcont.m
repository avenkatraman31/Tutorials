function y=panelcont(x,y,varargin)
% panel function to add smoothed contours

% Marko Laine <Marko.Laine@Helsinki.FI>
% $Revision: 1.2 $  $Date: 2002/09/12 11:15:07 $

[z,xx,yy] = hist2d([x(:),y(:)],[],10,0);
hold on
h=contour(xx,yy,z);
hold off
if nargout>1
  y=h;
end
