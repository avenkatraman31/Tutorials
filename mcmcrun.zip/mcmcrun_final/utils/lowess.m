function [ys,rw,res]=lowess(x,y,f,nsteps,delta)
% ys=lowess(x,y,f,nsteps,delta)
% lowess smooth for scatter plot points in x,y
% x should be sorted

% Marko Laine <Marko.Laine@Helsinki.FI>
% $Revision: 1.3 $  $Date: 2004/03/26 09:26:56 $

if any(isnan(y)) | length(y) == 0
  error('NaNs not allowed in lowess');
end

% sort x
[x,i]=sort(x);
y = y(i);

n = length(x);
if length(y) ~= n
  error('length(x) should be length(y)')
end
if nargin < 3
  f=0.5;
end
if nargin < 4
  nsteps=2;
end
if nargin < 5
  if n<100
    delta=0;
  else
    delta=(x(n)-x(1))/50;
  end
end
[ys,rw,res]=lowess_mexgw(x,y,f,nsteps,delta);
