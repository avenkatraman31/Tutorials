function y=plims(x,p)
% plims(x,p)  Empirical quantiles

% Marko Laine <Marko.Laine@Helsinki.FI>
% $Revision: 1.3 $  $Date: 2003/05/15 11:10:12 $

if nargin<2
%  p = [0.025,0.975];   
   p = [0.25,0.5,0.75];
end
[n,m] = size(x); if n==1; n=m;end
y = interp1(sort(x),(n-1)*p+1);
