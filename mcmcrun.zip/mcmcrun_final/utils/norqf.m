function y=norqf(x,mu,sigma2)
% NORQF Inverse of the normal (Gaussian) distribution.

% Marko Laine atkk 1991
% Uses the inverse error function INVERF

% Marko Laine <Marko.Laine@Helsinki.FI>
% $Revision: 1.3 $  $Date: 2003/10/31 19:36:58 $

if nargin < 2, mu     = 0; end
if nargin < 3, sigma2 = 1; end

% y=-sqrt(2)*inverf(1-2*x);
y= sqrt(sigma2).*sqrt(2).*erfinv(2*x-1)+mu;

