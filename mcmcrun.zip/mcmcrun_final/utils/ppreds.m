function ppreds(y,ynoisy,x,obs,p)
%
%

ny=size(y,1); yint=[]; yinte=[];
nsample=size(y,2);
nsamplen=size(ynoisy,2);

for(i=1:ny)
   yi=interp1(sort(y(i,:)),(nsample-1)*p+1);
   yint=[yint;yi];
   
   if(~isempty(ynoisy))
       yie=interp1(sort(ynoisy(i,:)),(nsamplen-1)*p+1);
       yinte=[yinte;yie];
   end
   
end

Yfill=[yint(1,1) yint(:,3)' fliplr(yint(:,1)')];

if(~isempty(ynoisy))
  Yfille=[yinte(1,1) yinte(:,3)' fliplr(yinte(:,1)')];
end

Xfill=[x(1) x fliplr(x)];
Ymean=yint(:,2);
color_err=[0.9 0.9 0.9];
color_conf=[0.75 0.75 0.75];

if(~isempty(ynoisy))
  fill(Xfill,Yfille,color_err,'Linestyle','none');
end
hold on
fill(Xfill,Yfill,color_conf,'Linestyle','none');

plot(x,Ymean,'Linewidth',2,'Color',[0.7 0 0]);

if(~isempty(obs))
    % plot(obs(:,1),obs(:,2),'k.','MarkerSize',15);
    for(i=1:size(obs,1))
        if(obs(i,2) ~= 0)
            plot(obs(i,1),obs(i,2),'k.','MarkerSize',15);
        end
    end
end
hold off