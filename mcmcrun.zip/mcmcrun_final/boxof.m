function y = boxof(time,k)

[t,y] = ode45('boxode',time,[1;0],[],k);