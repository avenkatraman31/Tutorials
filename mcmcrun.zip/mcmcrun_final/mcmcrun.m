 function [results,chain,s2chain]=mcmcrun(model,data,params,options)
%function [results,chain,s2chain]=mcmcrun(model,data,params,options)
%MH (Metropolis-Hastings) MCMC run with options for adaptive delayed rejection (DRAM)
%
% The function generates MCMC chain for a model given together with a 
% user supplied sum-of-squares function. Additive i.i.d. Gaussian
% error is supposed for the observations. The error variance sigma2 may be updated
% using the conjugate inverse gamma distribution.
%
% INPUT:
% 
% model.ssfun =    ; % sum-of-squares function, ss=ssfun(par,data),
%                    % that returns  -2*log(p(y|par))
% model.priorfun = ; % prior "sum-of-squares", priorfun(par,params),
%                    % that returns -2*log(p(par)),
%                    % default: inline('0','x','params')
%
% data   = ;         % extra argument for ssfun (to pass the data etc.)
%
% params.par0   =  ; % initial parameter vector (a row vector)
% params.sigma2 =  1;% initial/prior value for the Gaussian error variance
% params.n0     = -1;% precision of sigma2 as imaginative observations
%                    %   if n0<0, no sigma2 update
% params.n      = ;  % number of actual observations (for sigma2 update)
% params.bounds = ;  % 2*npar matrix of parameter bounds
%                    % default: [-Inf,Inf]
%
% options.nsimu  = 10000;   % length of the chain
% options.qcov   = ;        % proposal covariance matrix. Initial, if adaptation used
%
% parameters for DR and AM
% options.adaptint = 10;  % how often to adapt.            if zero, no adaptation
% options.drscale  = 3;   % scale for the second proposal. if zero, no DR
%
% OUTPUT:
%
% results  structure that contains info about the run
% chain    the MCMC chain of size nsimu x npar
% s2chain  the sigma chain (if generated)

% calls covupd.m for covariance update and (optionally) gammar_mt.m for
% gamma variates

% this is a 'simple' version for demonstration and educational purposes

 global     chain chaincov chainmean wsum lasti
%covariance update uses these to store previous values
 chaincov = []; chainmean = []; wsum = []; lasti = 0;

[nsimu,par0,npar,bounds,ssfun,priorfun,adaptint,drscale,adascale,...
 qcoveps,n0,n,sigma2,qcov,dodr,s20,s2chain,R2,iR,printint,verbosity] =  ...
                                 optionfun(model,data,params,options);


chain        = zeros(nsimu,npar);          % store the chain here
oldpar       = par0(:)';                   % first row of the chain
oldss        = feval(ssfun,oldpar,data);   % first sum-of-squares
oldprior     = feval(priorfun,oldpar,params);
acce         = 1;                          %  how many accepted moves
chain(1,:)   = oldpar;
R            = chol(qcov);  % Cholesky factor of proposal covariance


%%% the simulation loop
for isimu=2:nsimu

  if isimu/printint == fix(isimu/printint) % info on every printint iteration
    fprintf('isimu=%d, %d%% done, accepted: %d%%\n',...
            isimu,fix(isimu/nsimu*100),fix((acce/isimu)*100));
  end
  
  newpar = oldpar+randn(1,npar)*R;     % a new proposal

  accept = 0;
  % check bounds first
  if any(newpar<bounds(1,:)) | any(newpar>bounds(2,:))
    newss    = Inf;
    newprior = 0;
    alpha    = 0;
  else % inside bounds, check if accepted
    newss    = feval(ssfun,newpar,data);   % sum-of-squares
    newprior = feval(priorfun,newpar,params); % prior ss
    alpha    = min(1,exp(-0.5*(newss-oldss)/sigma2 -0.5*(newprior-oldprior)));
    if rand < alpha % we accept
      accept   = 1;
      acce     = acce+1;
      oldpar   = newpar;
      oldss    = newss;
      oldprior = newprior;
    end
  end
  
%%%%%%%%%%%%%%%DR STEP %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  if accept == 0 & dodr    % step was rejected, but make a new try (DR)
    [oldpar,oldss,oldprior,acce]=drfun(data,params,bounds,ssfun,priorfun,...
                           R2,iR,alpha,sigma2,acce,...
                           oldprior,newprior,oldss,newss,oldpar,newpar);
  end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  chain(isimu,:) = oldpar; % save the present sample choice
  
%%%%% update the error variance sigma2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  if s20 > 0
    sigma2  = 1./gammar_mt(1,1,(n0+n)./2,2./(n0*s20+oldss));
    s2chain(isimu,:) = sigma2;
  end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  

%%%%%%%%%%%%%%%AM adaptation %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  if adaptint>0 & fix(isimu/adaptint) == isimu/adaptint
    [R,R2,iR]=amfun(isimu,npar,qcoveps,adascale,verbosity,dodr,drscale);
  end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

end

% FInal calculation of covariance and mean of the chain
[chaincov,chainmean,wsum] = covupd(chain((lasti+1):isimu,:),1, ...
                                   chaincov,chainmean,wsum);


% Collect the results
results.class = 'MCMC results';
results.accepted=acce./nsimu;              % acceptance ratio
results.mean = chainmean;
results.cov  = chaincov;
results.qcov = R'*R;
results.R = R;
results.nsimu = nsimu;
results.drscale = drscale;
results.adascale = adascale;
results.adaptint = adaptint;





%%%%%%%%%%%%%%%%%%%auxiliary functions %%%%%%%%%%%%%%%%%%%%%%%%%%%

function y=getpar(options,par,default)
%GETPAR get parameter value from a struct
% options   options struct
% par       parameter value to extract from the struct
% default   default value if par is not a member of the options struct

if isfield(options,par)
  y = getfield(options,par);
elseif nargin>2
  y = default;
else
  error(sprintf('Need value for option: %s',par));
end

%%%function for initial OPTIONS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [nsimu,par0,npar,bounds,ssfun,priorfun,adaptint,drscale,adascale,...
          qcoveps,n0,n,sigma2,qcov,dodr,s20,s2chain,R2,iR,printint,verbosity] =  ...
          optionfun(model,data,params,options);

%% get values from the input structs
nsimu  = getpar(options,'nsimu',10000);
% initial parameter vector
par0   = getpar(params,'par0'); par0=par0(:)'; % row vector
% number of parameters
npar   = length(par0);
% 2*npar matrix of parameter bounds
bounds = getpar(params,'bounds',(ones(npar,2)*diag([-Inf,Inf]))');
% sum-of-squares function, ssfun(par,data),  -2*log(p(y|theta))
ssfun  = getpar(model,'ssfun');
% prior "sum-of-squares", -2*log(p(theta))
priorfun = getpar(model,'priorfun',inline('0','x','params'));

%%% parameters for DRAM
% how often to adapt, if zero, no adaptation
adaptint = getpar(options,'adaptint',100);
% scale for the second proposal, if zero, no DR
drscale  = getpar(options,'drscale',3);
% scale for adapting the propsal
adascale = getpar(options,'adascale',2.4/sqrt(npar));
% blow factor for covariace update
qcoveps  = getpar(options,'qcoveps',1e-5);

% precision of sigma2 as imaginative observations
%  if n0<0, no sigma2 update
n0  = getpar(params,'n0',-1);
% initial/prior value for the Gaussian error variance
sigma2 = getpar(params,'sigma2',1);
% number of observations (needed for sigma2 update)
n=[]; if n0>=0, n = getpar(params,'n'); end

qcov = getpar(options,'qcov'); % proposal covariance

% to DR or not to DR
if drscale<=0, dodr=0; else dodr=1;end

R = chol(qcov);  % Cholesky factor of proposal covariance
if dodr
  R2 = R./drscale;     % second proposal for DR try
  iR = inv(R);
else
  R2 = [];,iR=[];
end

s20 = 0;
if n0>=0
  s2chain = zeros(nsimu,1);   % the sigma2 chain
  s20 = sigma2;
  if s20>0
    s2chain(1,:) = sigma2;
  end
else
  s2chain = [];
end

printint  = getpar(options,'printint',500);
verbosity = getpar(options,'verbosity',0);


%%%function for a one-stage DELAYED REJECTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 function [oldpar,oldss,oldprior,acce]=drfun(data,params,bounds,ssfun,priorfun,...
                                  R2,iR,alpha12,sigma2,acce,...
                                  oldprior,newprior,oldss,newss,oldpar,newpar)

  npar    = length(oldpar);
  newpar2 = oldpar+randn(1,npar)*R2;  % a new try

  if any(newpar2<bounds(1,:)) | any(newpar2>bounds(2,:))
     newss2 = Inf;
     newprior2 = 0;
  else % inside bounds
     newss2    = feval(ssfun,newpar2,data);
     newprior2 = feval(priorfun,newpar2,params);
     alpha32 = min(1,exp(-0.5*(newss-newss2)/sigma2 -0.5*(newprior-newprior2)));
     l2 = exp(-0.5*(newss2-oldss)/sigma2 - 0.5*(newprior2-oldprior));
     q1 = exp(-0.5*(norm((newpar2-newpar)*iR)^2-norm((oldpar-newpar)*iR)^2));
     alpha13 = l2*q1*(1-alpha32)/(1-alpha12);
     if rand < alpha13 % we accept
       accept = 1;
       acce     = acce+1;
       oldpar   = newpar2;
       oldss    = newss2;
       oldprior = newprior2;
      end
  end


%%%function for VARIANCE/COVARIANCE SAMPLING %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% not implemented
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%function for adaptation %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 function [R,R2,iR]=amfun(isimu,npar,qcoveps,adascale,verbosity,dodr,drscale);
 global     chain chaincov chainmean wsum lasti
 %persistent chaincov chainmean wsum lasti

 if verbosity fprintf('adapting\n'); end
 if isempty(lasti);lasti = 0; end

 [chaincov,chainmean,wsum] = covupd(chain((lasti+1):isimu,:),1, ...
                                    chaincov,chainmean,wsum);
 lasti   = isimu;
 [Ra,is] = chol(chaincov + eye(npar)*qcoveps);
 if is % singular cmat
   fprintf('Warning cmat singular, not adapting\n');
 else
   R = Ra*adascale;R2 = [];iR=[];
   if dodr
     R2 = R./drscale;     % second proposal for DR try
     iR = inv(R);
   end
 end



