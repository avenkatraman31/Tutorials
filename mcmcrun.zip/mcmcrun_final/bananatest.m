%%%% SAMPLING FROM A BANANA SHAPED DISTRIBUTION %%%%

%%------------- INITIALIZATION --------------%%

addpath([pwd,filesep,'utils']);

nsimu=10000; npar=10; % number of points and parameters

pars.C=diag([100 ones(1,npar-1)]); % target covariance
pars.b=0.1; % twisting parameter, the greater the value the bigger twisting effect
pars.mu=zeros(1,npar); % the MAP point in the non-twisted gaussian
pars.map=[0 100*pars.b zeros(1,npar-2)]; % MAP point in the twisted gaussian

update=1000; % how often we update in AM
initpar=[0 100*pars.b zeros(1,npar-2)]+1*randn(1,npar); % start close to the MAP point
propcov=2.4/sqrt(npar)*pars.C; % initial proposal covariance


%%---------------MCMC-------------%%

model.ssfun   = @bananass;

params.par0   = initpar;

options.nsimu = nsimu;
options.qcov = propcov;
options.adaptint = update;

[results,chain] = mcmcrun(model,pars,params,options);


%%----------- PLOTTING -----------%%%

plot(chain(:,1),chain(:,2),'r.');
