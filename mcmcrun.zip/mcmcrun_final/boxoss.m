function ss = boxoss(k,data)

time = data.tdata;
AB   = data.ydata;;
y0   = AB(1,:);

[t,y] = ode45('boxode',time,y0,[],k);

ss    = sum(sum((AB-y).^2));



