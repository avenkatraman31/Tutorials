%% Demonstrating MCMC with simple chemical kinetics
%% The reaction system A -> B -> C given as an ODE system

clear all; close all;

load boxodata.dat  % load data
time = boxodata(:,1); 
AB   = boxodata(:,2:3);
A0 = 1; B0 = 0;  y0 = [A0; B0]; % initial values

time = [0; time];   AB = [y0'; AB]; % add the time point t=0
data.tdata=time; data.ydata=AB; % define data structure for mcmcrun

k0 = [1 1]; % inital guess for optimization
[k_fit,rss]  = fminsearch('boxoss',k0,[],data) % minimizing LSQ

%%% estimate measurement error from fitted values
n     = 2*(size(AB,1)-1);    % number of observations (not the point t=0 !)
p     = 2;                   % number of parameters
sigma2= rss./(n-p);          % mean squared error

%% Compute the approximative cov matrix for parameters
J = jacob(@boxof,data.tdata,k_fit);
                   
cov_from_fit = sigma2*inv(J'*J);

%%%%%%%%%%%% MCMC %%%%%%%%%%%%%%%%

model.ssfun   = @boxoss;

params.par0   = k_fit;
params.sigma2 = sigma2;
params.bounds = [zeros(p,1), 2*ones(p,1)]';

nsamples      = 2000;
options.nsimu = nsamples;
options.qcov = cov_from_fit.*2.4^2./p;

[results,chain] = mcmcrun(model,data,params,options);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


figure(1);
mcmcplot(chain,[],[],'pairs'); % Plotting MCMC chain for parameters


% calculate & plot the distributions of B:
skip=20; % take every skip:th parameter from the chain
tmin=0; tmax=40; ntt=100; % ntt: how many time points between tmin and tmax
tt = linspace(tmin,tmax,ntt);  %predictions outside the exper.range 
risk=0.05; % risk level for prediction plot

BB = zeros(ntt,length(1:skip:nsamples));
j=1;
for k=1:skip:nsamples
  [t,y_pred] = ode45('boxode',tt,y0,[],chain(j,:));
  BB(:,j) = y_pred(:,2);
  j=j+1;
end;

[t,y_fit] = ode45('boxode',tt,y0,[],k_fit);

%obs=[data.tdata data.ydata(:,2)];  % UNCOMMENT TO PLOT OBSERVATIONS
obs = [];

figure(2);
ppreds(BB,[],tt,obs,[risk/2 0.5 1-risk/2]);
hold on
plot(tt,y_fit(:,2),'b-'); % Plotting the LSQ-fit too
hold off