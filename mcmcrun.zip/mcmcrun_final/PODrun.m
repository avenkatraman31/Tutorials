% Testing MCMC in a simple case
% POD model, y=b1*(1-exp(-b2*x))

% Model function: podfun.m
% Sum of squares function: podss.m

clear all; close all;

% Data
data.tdata = (1:2:9)';
data.ydata = [0.076 0.258 0.369 0.492 0.559]';

b_0 = [1 0.1]; 
[bmin,ssmin]=fminsearch(@podss2,b_0,[],data); % LSQ optimum

J = jacob(@podfun,data.tdata,bmin);  % numerical Jacobian

n=length(data.tdata); p = length(b_0);
mse = ssmin/(n-p); % mean squared error

cmat = mse*inv(J'*J);

nsimu    = 5000;

%%%%%%%%%%%% MCMCRUN -PART %%%%%%%%%%%%%%

model.ssfun    = @podss2;

params.par0    = bmin; % initial parameter values
params.sigma2  = mse;  % error variance sigma^2

options.nsimu    = nsimu;               % size of the chain
options.qcov     = cmat.*2.4^2./p;      % initial proposal covariance
options.adaptint = 500;                 % adaptation interval

% run the chain
[results,chain] = mcmcrun(model,data,params,options);


%%%%%%%%%%%% PLOTTING %%%%%%%%%%%%%%%%%%%%%%

figure(1);clf
t = linspace(0,10);
plot(data.tdata,data.ydata,'o',t,podfun(t,bmin),'-')
legend('data','LSQ estimate',0)

figure(2);clf
plot(chain(:,1),chain(:,2),'.')
xlabel('b_1'); ylabel('b_2');title('MCMC chain');

figure(3);clf
subplot(2,1,1)
plot(chain(:,1),'.');ylabel('b_1');
title(sprintf('MCMC chain. Accepted %.1f%%',results.accepted*100))

subplot(2,1,2)
plot(chain(:,2),'.');ylabel('b_2');
