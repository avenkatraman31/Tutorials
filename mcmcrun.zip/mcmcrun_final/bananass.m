function ss=bananass(x,pars)
% "artificial" sum of squares for the mcmcrun banana demo
% x     : point in the twisted gaussian
% pars  : see bananatest2

xz=[x(:,1) x(:,2)+pars.b.*x(:,1).^2-100*pars.b x(:,3:end)];
ss=(pars.mu-xz)*inv(pars.C)*(pars.mu-xz)';