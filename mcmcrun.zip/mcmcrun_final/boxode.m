function ydot = boxode(t,y,flags,k)

A=y(1); B=y(2);

dA =  -k(1)*A;
dB =   k(1)*A - k(2)*B;

ydot = [dA; dB];

