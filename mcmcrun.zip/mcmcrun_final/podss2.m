function ss=podss(theta,data)

global SS_count
SS_count = SS_count+1;

x = data.tdata;
y = data.ydata;

ss = sum((y - theta(1)*(1-exp(-theta(2)*x))).^2);
